<?php

require '../config.php';
$busId = $_POST["busId"];
$r = $DB->query("SELECT * from `buses` where `id`=$busId")->fetch_assoc()["seat_map"];
if ($DB->errno) {
	header("HTTP/1.0 500 Bad query ({$DB->errno}) {$DB->error}");
	die();
} else {
	echo $r;
}

?>
